from fastapi import FastAPI, UploadFile, File, Query
from fastapi.middleware.cors import CORSMiddleware
import phonenumbers
import socket
import requests

app = FastAPI(title="Persona Finder OSINT API")

# -----------------------------
# CORS (MANDATORY)
# -----------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -----------------------------
# TOOL 1: USERNAME LOOKUP
# -----------------------------
@app.get("/api/username")
def username_lookup(username: str = Query(..., min_length=2)):
    platforms = {
        "GitHub": f"https://github.com/{username}",
        "Twitter": f"https://twitter.com/{username}",
        "Instagram": f"https://www.instagram.com/{username}",
        "Reddit": f"https://www.reddit.com/user/{username}",
    }

    results = []
    for platform, url in platforms.items():
        try:
            r = requests.head(url, timeout=5)
            exists = r.status_code == 200
        except:
            exists = False

        results.append({
            "platform": platform,
            "exists": exists,
            "url": url
        })

    return {
        "username": username,
        "checked": len(results),
        "found": sum(r["exists"] for r in results),
        "results": results
    }

# -----------------------------
# TOOL 2: PHONE NUMBER OSINT
# -----------------------------
@app.get("/api/phone")
def phone_lookup(number: str):
    try:
        parsed = phonenumbers.parse(number, None)
        valid = phonenumbers.is_valid_number(parsed)

        country = phonenumbers.region_code_for_number(parsed)
        carrier = phonenumbers.carrier.name_for_number(parsed, "en")
        phone_type = phonenumbers.number_type(parsed)

        return {
            "phone": number,
            "valid": valid,
            "country": country,
            "carrier": carrier,
            "type": str(phone_type),
            "osint_links": {
                "Google": f"https://www.google.com/search?q={number}",
                "Truecaller": f"https://www.truecaller.com/search/{country.lower()}/{number[-10:]}"
            }
        }

    except:
        return {
            "phone": number,
            "valid": False,
            "error": "Invalid phone number format"
        }

# -----------------------------
# TOOL 3: IP / DOMAIN INTEL
# -----------------------------
@app.get("/api/ip")
def ip_lookup(target: str):
    try:
        ip = socket.gethostbyname(target)
    except:
        return {"error": "Invalid IP or domain"}

    return {
        "input": target,
        "resolved_ip": ip,
        "osint_links": {
            "WHOIS": f"https://who.is/whois-ip/ip-address/{ip}",
            "AbuseIPDB": f"https://www.abuseipdb.com/check/{ip}",
            "VirusTotal": f"https://www.virustotal.com/gui/ip-address/{ip}"
        }
    }

# -----------------------------
# TOOL 4: IMAGE OSINT
# -----------------------------
@app.post("/api/image")
async def image_osint(file: UploadFile = File(...)):
    filename = file.filename

    return {
        "filename": filename,
        "reverse_search_links": {
            "Google Images": "https://images.google.com/",
            "Yandex Images": "https://yandex.com/images/",
            "Bing Visual": "https://www.bing.com/images/",
            "TinEye": "https://tineye.com/"
        }
    }
